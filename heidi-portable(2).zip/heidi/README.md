# Heidi

Heidi é um gerenciador simples para **pacotes locais do Arch Linux**. Usa o `pacman` para instalar e remover programas; não substitui o `pacman` nem baixa pacotes da internet.

## Requisitos

- Arch Linux ou distribuição compatível com `pacman`
- Python 3 e `pacman`
- `sudo` para instalar ou remover programas

## Instalação

Na pasta do projeto:

```bash
chmod +x heidi install.sh
./install.sh
```

O instalador coloca o comando em `/usr/local/bin/heidi`, disponível globalmente naquele computador. Em outro computador, copie/clonе o projeto e execute o instalador novamente.

## Comandos

```bash
heidi -l                    # listar pacotes no catálogo local
heidi -s discord            # pesquisar por nome ou descrição
heidi -i nome-do-pacote     # instalar pacote do repositório local
heidi -y                    # pesquisar os arquivos e atualizar packages.json
heidi --research            # forma longa de -y
heidi -r nome-do-pacote     # desinstalar pacote instalado
heidi --remove nome-do-pacote
heidi --help
```

## Pesquisa automática de pacotes locais

Coloque arquivos de pacote do Arch Linux, como `*.pkg.tar.zst`, na pasta `pacotes/` dentro do repositório. Depois execute:

```bash
heidi -y
```

O Heidi valida os arquivos com `pacman -Qp` e lê os metadados `.PKGINFO` com `bsdtar`, que faz parte do conjunto de ferramentas de arquivo do Arch Linux. Ele adiciona ou atualiza os registros correspondentes em `packages.json`. Arquivos inválidos ou que o `pacman` não consiga ler são ignorados com um aviso. O Heidi não apaga automaticamente registros antigos do catálogo.

## Onde ficam os dados?

Por padrão, o Heidi cria esta estrutura para cada usuário:

```text
~/.local/share/heidi/
├── packages.json
└── pacotes/
```

Se quiser usar outro diretório, defina `HEIDI_REPO_DIR`. Por exemplo:

```bash
export HEIDI_REPO_DIR="$HOME/heidi-repositorio"
heidi -y
```

Esse diretório deve conter `packages.json` e `pacotes/`. Para tornar a variável permanente no Bash, adicione a linha `export HEIDI_REPO_DIR="$HOME/heidi-repositorio"` ao `~/.bashrc`.

## Exemplo de registro

O Heidi gera os registros a partir dos metadados dos arquivos, mas o formato é semelhante a:

```json
{
  "packages": [
    {
      "name": "exemplo",
      "version": "1.0-1",
      "file": "exemplo-1.0-1-x86_64.pkg.tar.zst",
      "description": "Descrição do pacote"
    }
  ]
}
```

## Segurança e limitações

- Instale apenas pacotes de origem confiável.
- `heidi -i` chama `sudo pacman -U`. Dependências ausentes podem exigir internet.
- `heidi -r` chama `sudo pacman -R`, que normalmente remove o pacote indicado sem remover automaticamente suas dependências. O `pacman` mostra a operação e solicita confirmação; revise-a antes de aceitar.
- O Heidi não verifica assinaturas por conta própria e não substitui os mecanismos de confiança do Arch Linux.
- Pacotes precisam ser compatíveis com a arquitetura e a versão do sistema.
