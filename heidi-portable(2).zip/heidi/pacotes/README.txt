Coloque aqui os arquivos de pacote do Arch Linux (*.pkg.tar.zst, por exemplo).
Depois execute: heidi -y
