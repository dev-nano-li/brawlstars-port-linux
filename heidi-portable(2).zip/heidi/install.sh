#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE="$SCRIPT_DIR/heidi"
DEST="/usr/local/bin/heidi"

if [[ ! -f "$SOURCE" ]]; then
    echo "Erro: não encontrei o executável '$SOURCE'." >&2
    exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
    echo "Erro: Python 3 não está instalado." >&2
    exit 1
fi

python3 -m py_compile "$SOURCE"
sudo install -Dm755 "$SOURCE" "$DEST"
echo "Heidi instalado em $DEST"
echo "Teste com: heidi --help"
echo "Os dados do usuário serão criados em ~/.local/share/heidi na primeira execução."
